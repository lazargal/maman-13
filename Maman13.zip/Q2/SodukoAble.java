
/**
 * An Interface for the Soduko cell. 
 * allows the implementing object to take car of the data visualization regardless of the Soduko logics 
 *
 */
public interface SodukoAble
{
    
    public enum SodukoState{UNSET , AWAITS_APROVAL_PRESET , SET , GAME_CHANGEABLE , AWAITS_APROVAL_IN_GAME};
    int getRow();
    int getColumn();
    int getCurrentCellValue();
    void setCellValue(int nValue);
    SodukoState getCurrentState();
    void setCurrentState(SodukoState newState);    

}
