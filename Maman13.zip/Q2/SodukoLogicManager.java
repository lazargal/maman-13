import java.util.ArrayList;

import javax.swing.JOptionPane;


/**
 * 
 * This class acts as a manager for the Soduko logic.
 * the class is responsible for validating the each row,column and block.
 * each board should have only one instance of this object and all the cells should be linked to this object 
 *
 */
public class SodukoLogicManager
{
    private int m_nNumOFRowAndColumn = SodukoPanel.LINE_NUM_OF_CELLS;	// number of line and rows in the board
    private SodukoAble[][] m_cellArray = new SodukoAble[m_nNumOFRowAndColumn][m_nNumOFRowAndColumn]; // an array of cells that represent the board
    private boolean m_bBoardIsLocked = false; // indication if the board is locked or not
    
    // class constructor
    SodukoLogicManager(int nNumOfRowsAndColumns)
    {
	if(nNumOfRowsAndColumns > 0)
	    m_nNumOFRowAndColumn = nNumOfRowsAndColumns;
	
	if(m_nNumOFRowAndColumn != SodukoPanel.LINE_NUM_OF_CELLS)
	    throw new IllegalArgumentException("SodukoLogicManager: nNumOfRowsAndColumns should be SodukoPanel.LINE_NUM_OF_CELLS");
	
	resetCellArray();
	
    }
    
    // reset the cell array to null
    private void resetCellArray()
    {
	m_cellArray = new SodukoAble[m_nNumOFRowAndColumn][m_nNumOFRowAndColumn];
	for(int i = 0 ; i < m_cellArray.length ; i++)
	{
	    for(int j = 0 ; j < m_cellArray[i].length ; j++)
	    {
		m_cellArray[i][j] = null;
	    }
	}
    }
    
    // m_nNumOFRowAndColumn getter
    public int getNumOfRowAndColumns()
    {
	return m_nNumOFRowAndColumn;		
    }
    
    // adds a single cell to the array. if a cell already exist in that position then the function will return flase
    public boolean addCell(SodukoAble cellToAdd)
    {
	
	if(Math.min(cellToAdd.getColumn() , cellToAdd.getRow())  < 0 || Math.max(cellToAdd.getColumn() , cellToAdd.getRow()) >= m_nNumOFRowAndColumn )
	    return false;
	
	if(m_cellArray[cellToAdd.getRow()][cellToAdd.getColumn()] == null)
	    m_cellArray[cellToAdd.getRow()][cellToAdd.getColumn()] = cellToAdd;
	else
	    return false;
	
	return true;
    }

    // checks if the sent value is a valid number in the board 
    public boolean isValidValue(int nValue)
    {
	if(nValue > 0 && nValue <= m_nNumOFRowAndColumn)
	    return true;
	else
	    return false;	
    }
    
    @SuppressWarnings("unchecked")
    // checks if the current values of the cells are valid
    public boolean isBoardValid()
    {
	
	ArrayList<Integer>[] rowsArray = new ArrayList[m_nNumOFRowAndColumn];
	ArrayList<Integer>[] columnsArray = new ArrayList[m_nNumOFRowAndColumn];
	ArrayList<Integer>[] squersArray = new ArrayList[m_nNumOFRowAndColumn];
	
	for(int i = 0 ; i < m_nNumOFRowAndColumn ; i ++)
	{
	    rowsArray[i] = new ArrayList<Integer>();
	    columnsArray[i] = new ArrayList<Integer>();
	    squersArray[i] = new ArrayList<Integer>();
	}
	
	for(int i = 0 ; i < m_nNumOFRowAndColumn ; i ++)
	{
	    for(int j = 0; j < m_nNumOFRowAndColumn ; j++)
	    {
		int nCurrCellValue = m_cellArray[i][j].getCurrentCellValue();
		if(m_cellArray[i][j].getCurrentState() != SodukoAble.SodukoState.UNSET && isValidValue(nCurrCellValue))
		{
		    rowsArray[i].add(nCurrCellValue);
		    columnsArray[j].add(nCurrCellValue);
		    int nTempIndex = 3*(i/3) + j/3; 
		    squersArray[nTempIndex].add(nCurrCellValue);
		}
	    }
	}
	
	
	for(int i = 0 ; i < m_nNumOFRowAndColumn ; i ++)
	{
	    if(!isBlockValid(rowsArray[i], m_nNumOFRowAndColumn))
		return false;
	    if(!isBlockValid(columnsArray[i], m_nNumOFRowAndColumn))
		return false;
	    if(!isBlockValid(squersArray[i], m_nNumOFRowAndColumn))
		return false;	    
	}
	
	return true;
    }
    
    // update the board cells value and removes all illegal cells values, if any cells where removed then the function will return false.
    // if the board current status is valid then all the legal AWAITS_APROVAL cells values are set. 
    public boolean validateAndSetBoard()
    {
	boolean bTempRes = isBoardValid(); 
	for(int i = 0 ; i < m_cellArray.length ; i++)
	{
	    for(int j = 0 ; j < m_cellArray[i].length ; j++)
	    {
		if(m_cellArray[i][j].getCurrentState() == SodukoAble.SodukoState.AWAITS_APROVAL_PRESET || m_cellArray[i][j].getCurrentState() == SodukoAble.SodukoState.AWAITS_APROVAL_IN_GAME )
		{
		    if(bTempRes)
		    {
			if(m_cellArray[i][j].getCurrentState() == SodukoAble.SodukoState.AWAITS_APROVAL_PRESET)
			    m_cellArray[i][j].setCurrentState(SodukoAble.SodukoState.SET);
			else
			    m_cellArray[i][j].setCurrentState(SodukoAble.SodukoState.GAME_CHANGEABLE);			
		    }
		    else
		    {
			if(m_cellArray[i][j].getCurrentState() == SodukoAble.SodukoState.AWAITS_APROVAL_PRESET)
			    m_cellArray[i][j].setCurrentState(SodukoAble.SodukoState.UNSET);
			else
			    m_cellArray[i][j].setCurrentState(SodukoAble.SodukoState.GAME_CHANGEABLE);
			m_cellArray[i][j].setCellValue(-1);
		    }
		}
	    }
	}	
	
	return bTempRes;
    }
    
    // checks the validation of a single block of cells ( a block is a set of cells that must be unique in their value between 1 to nNumOfCellsInBlock)   
    private boolean isBlockValid(ArrayList<Integer> cellsValueArray , int nNumOfCellsInBlock)
    {
	boolean[] dataArray = new boolean[nNumOfCellsInBlock];
	
	for(int i = 0 ; i < nNumOfCellsInBlock ; i++)
	{
	    dataArray[i] = false;
	}
	
	for(Integer nCurrCellValue : cellsValueArray)
	{
	    int nTempDataIndex = nCurrCellValue-1;
	    if(nTempDataIndex < 0 || nTempDataIndex >= nNumOfCellsInBlock )
		throw new IllegalArgumentException("validateSingleBlock: nTempDataIndex = " +nTempDataIndex);
	    
	    if(dataArray[nTempDataIndex] == true)
		return false;
	    dataArray[nTempDataIndex] = true;
	}
	
	
	return true;
    }

    // clear the entire board data and reset it to empty cells
    public void clearBoard()
    {
	for(int i = 0 ; i < m_cellArray.length ; i++)
	{
	    for(int j = 0 ; j < m_cellArray[i].length ; j++)
	    {
		m_cellArray[i][j].setCurrentState(SodukoAble.SodukoState.UNSET);
		m_cellArray[i][j].setCellValue(-1);
	    }
	}
	setLockBoard(false);
    }
    
    // m_bBoardIsLocked setter
    private void setLockBoard(boolean bLock)
    {
	m_bBoardIsLocked = bLock;
    }
    
    public boolean isBoardLocked()
    {
	return m_bBoardIsLocked;
    }
    
    // lock the current settings of the board and enables the user to play. if the current board is not valid then a message is presented to the user and the board is not loacked
    public boolean lockBoard()
    {
	if(!validateAndSetBoard())
	{
	    JOptionPane.showMessageDialog(null, "Current board settings are not applicable for locking ", "Board Not Set", JOptionPane.ERROR_MESSAGE);
	    return false;
	}
	for(int i = 0 ; i < m_cellArray.length ; i++)
	{
	    for(int j = 0 ; j < m_cellArray[i].length ; j++)
	    {
		if(m_cellArray[i][j].getCurrentState() != SodukoAble.SodukoState.SET)
		    m_cellArray[i][j].setCurrentState(SodukoAble.SodukoState.GAME_CHANGEABLE);
	    }
	}

	setLockBoard(true);
	return true;
    }

}
