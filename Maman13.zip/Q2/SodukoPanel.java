
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class SodukoPanel extends JPanel
{
    public final static int LINE_NUM_OF_CELLS = 9;	// the program is built for 9 cells in each row and column, different numbers should be tested thoroughly 
    private SodukoTextField[][] m_cellsArray = new SodukoTextField[LINE_NUM_OF_CELLS][LINE_NUM_OF_CELLS];	// the cells array.
    private SodukoLogicManager m_myMngr = new SodukoLogicManager(LINE_NUM_OF_CELLS); 	// the board logic manager.
    
    // class constructor
    public SodukoPanel()
    {
	super();
	setLayout(new GridLayout(LINE_NUM_OF_CELLS/3, LINE_NUM_OF_CELLS/3));
	JPanel[] blocksPanelArray = new JPanel[LINE_NUM_OF_CELLS];
	
	for(int i = 0 ; i < LINE_NUM_OF_CELLS ; i++)
	{
	    blocksPanelArray[i] = new JPanel(new GridLayout(LINE_NUM_OF_CELLS/3, LINE_NUM_OF_CELLS/3));
	    blocksPanelArray[i].setBorder(BorderFactory.createRaisedSoftBevelBorder());
	    add(blocksPanelArray[i]);
	}
	
	for(int i = 0  ; i < m_cellsArray.length ; i++)
	{
	    for (int j = 0 ; j < m_cellsArray[i].length ; j++)
	    {
		int nTempIndex = 3*(i/3) + j/3;
		m_cellsArray[i][j] = new SodukoTextField( i, j ,m_myMngr);
		setCellBackground(m_cellsArray[i][j] , nTempIndex , false);
		blocksPanelArray[nTempIndex].add(m_cellsArray[i][j]);
	    }
	}
    }
    
    // sets the cells background according to the locking state of the board
    private void setCellBackground(SodukoTextField cell , int nBlockIndex , boolean bBoardIsLocked)
    {
	if(nBlockIndex % 2 == 0)
	{
	    if(bBoardIsLocked)
		cell.setBackground(Color.WHITE);
	    else
		cell.setBackground(Color.LIGHT_GRAY);
	}
	else
	{
	    if(bBoardIsLocked)
		cell.setBackground(Color.LIGHT_GRAY);
	    else
		cell.setBackground(Color.WHITE);
	}
    }

    // locks the board and allow the user to star solving it.
    public void lockBoard()
    {
	if(m_myMngr.isBoardLocked())
	{
	    JOptionPane.showMessageDialog(null, "The board is already set. press the Clear button before pressing Set again", "Board Locked", JOptionPane.ERROR_MESSAGE);
	}
	m_myMngr.lockBoard();
	for(int i = 0  ; i < m_cellsArray.length ; i++)
	{
	    for (int j = 0 ; j < m_cellsArray[i].length ; j++)
	    {
		int nTempIndex = 3*(i/3) + j/3;
		setCellBackground(m_cellsArray[i][j] , nTempIndex , true);
		m_cellsArray[i][j].repaint();
	    }
	}
    }
    
    // clears the content of the board and unlocks it.
    public void clearBoard()
    {
	m_myMngr.clearBoard();
	for(int i = 0  ; i < m_cellsArray.length ; i++)
	{
	    for (int j = 0 ; j < m_cellsArray[i].length ; j++)
	    {
		int nTempIndex = 3*(i/3) + j/3;
		setCellBackground(m_cellsArray[i][j] , nTempIndex , false);
		m_cellsArray[i][j].repaint();
	    }
	}
    }

}
