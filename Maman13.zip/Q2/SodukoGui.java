import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SodukoGui 
{

    public static void main(String[] args)
    {
	JButton setButton = new JButton("Set");
	JButton clearButton = new JButton("Clear");
	JPanel lowBtnsPanel = new JPanel();
	final SodukoPanel sodukoPanel = new SodukoPanel();
	JFrame mainWindow = new JFrame("Soduko");
	
	setButton.addActionListener(new ActionListener()
	{
	    @Override
	    public void actionPerformed(ActionEvent e)
	    {
		sodukoPanel.lockBoard();
	    }
	});
	
	clearButton.addActionListener(new ActionListener()
	{
	    @Override
	    public void actionPerformed(ActionEvent e)
	    {
		sodukoPanel.clearBoard();
	    }
	});
	
	mainWindow.setSize(800, 600);
	mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	lowBtnsPanel.add(setButton);
	lowBtnsPanel.add(clearButton);
	mainWindow.add(sodukoPanel);
	mainWindow.add(lowBtnsPanel , BorderLayout.SOUTH);
	mainWindow.setVisible(true);
    }
}
