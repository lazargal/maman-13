import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class SodukoTextField extends JTextField implements SodukoAble , ActionListener
{
    private int m_nMyRow = 0;	// object row in the board
    private int m_nMyColumn = 0;	// object column in the board
    private SodukoLogicManager m_myMngr = null;	// a reference to the soduko manager object
    private int m_nValue = -1;	// the cell default value	
    private SodukoState m_myState = SodukoState.UNSET;// the cell default state 
    private Font m_currentFont = new Font("Ariel" , Font.PLAIN , 12);	// the cell font
    
    // class constructor. if sent values are not applicable a relevant exception is thrown
    SodukoTextField(int nRow , int nColumn , SodukoLogicManager myMngr)
    {
	super();
	if(myMngr == null || Math.min(nRow,nColumn) < 0  || Math.max(nRow,nColumn) >= myMngr.getNumOfRowAndColumns())
	{
	    StringBuilder strTemp = new StringBuilder();
	    strTemp.append("SodukoTextField initialization with illeagal arguments \n");
	    if(myMngr == null)
		strTemp.append("myMngr == null");
	    else
	    {
		if(nRow < 0 || nRow > myMngr.getNumOfRowAndColumns())
		    strTemp.append("nRow = " + nRow);
		if(nColumn < 0 || nColumn > myMngr.getNumOfRowAndColumns())
		    strTemp.append("nColumn = " + nColumn);
	    }
	    throw new IllegalArgumentException( strTemp.toString());
	}
	m_nMyRow = nRow;
	m_nMyColumn = nColumn;
	m_myMngr = myMngr;
	
	if(!m_myMngr.addCell(this))
	    throw new IllegalArgumentException("A cell with the same row and column is allready set in the SodukoLogicManager nRow = "+ nRow + "nColumn = " + nColumn);

	setHorizontalAlignment(JTextField.CENTER);
	addActionListener(this);
	setFont(m_currentFont);
    }

    // get the current row of the SodukoAble object    
    @Override
    public int getRow()
    {
	return m_nMyRow;
    }

    // get the current column of the SodukoAble object    
    @Override
    public int getColumn()
    {
	return m_nMyColumn;
    }

    // get the current value of the SodukoAble object    
    @Override
    public int getCurrentCellValue()
    {
	return m_nValue;
    }

    // set the current value of the SodukoAble object    
    @Override
    public void setCellValue(int nValue)
    {
	String strTemp = new String();
	
	strTemp = "";
	if(m_myMngr != null && m_myMngr.isValidValue(nValue))
	{
	    m_nValue = nValue;
	    strTemp = String.format("%d", m_nValue);
	}
	else
	    m_nValue = -1;
	
	setText(strTemp);
	    
    }

    // get the current state of the SodukoAble object    
    @Override
    public SodukoState getCurrentState()
    {
	return m_myState;
    }

    // set the current state of the SodukoAble object
    @Override
    public void setCurrentState(SodukoState newState)
    {
	m_myState = newState;
	switch(m_myState )
	{
	case SET:
	    setEditable(false);
	    m_currentFont = new Font("Ariel" , Font.BOLD , m_currentFont.getSize());
	    setForeground(Color.BLUE);
	    break;
	case UNSET:
	    m_currentFont = new Font("Ariel" , Font.PLAIN , m_currentFont.getSize());
	    setEditable(true);	    
	    setForeground(Color.BLACK);
	    break;
	}
	setFont(m_currentFont);
    }

    // enter is pressed in the text field
    @Override
    public void actionPerformed(ActionEvent actionEvnt)
    {
	if(m_myMngr == null)
	    throw new RuntimeException("SodukoTextField: actionPerformed when m_myMngr == null");
	
	if(m_myState == SodukoState.SET)
	{
	    JOptionPane.showMessageDialog(null, "This cell data is already set ", "Cell Is Set", JOptionPane.ERROR_MESSAGE);
	    return;
	}
	
	int nTempVal = 0;
	String strTemp = getText();
	strTemp.trim();
	try
	{
	    nTempVal = Integer.parseInt(strTemp);
	}
	catch(NumberFormatException numExcp)
	{
	    nTempVal = -1;
	}
	
	if(m_myMngr.isValidValue(nTempVal))
	{
	    m_nValue = nTempVal;
	    setText(strTemp);
	}
	else
	{
	    JOptionPane.showMessageDialog(null, "The entered data is not applicable ", "Number Deleted", JOptionPane.ERROR_MESSAGE);
	    strTemp = "";
	    setText(strTemp);
	    m_nValue = -1;
	    return;
	}
	
	
	if(getCurrentState() == SodukoState.UNSET)
	    setCurrentState(SodukoState.AWAITS_APROVAL_PRESET);	
	else if(getCurrentState() == SodukoState.GAME_CHANGEABLE)
	    setCurrentState(SodukoState.AWAITS_APROVAL_IN_GAME);
	else
	    assert false : "SodukoTextField actionPerformed: getCurrentState() != SodukoState.GAME_CHANGEABLE && getCurrentState() != SodukoState.UNSET";
	
	    
	if(!m_myMngr.validateAndSetBoard())
	{
	    JOptionPane.showMessageDialog(null, "The entered nuber is not applicable ", "Number Deleted", JOptionPane.ERROR_MESSAGE);
	    m_nValue = -1;
	}
    }
    
    // update the cell font size
    @Override
    public void paintComponent(Graphics gragphicsObj)    
    {
	super.paintComponent(gragphicsObj);
	int nTempHeight = getHeight();
	m_currentFont = new Font(m_currentFont.getFontName() , m_currentFont.getStyle() , nTempHeight-2);
	setFont(m_currentFont);
    }

}
